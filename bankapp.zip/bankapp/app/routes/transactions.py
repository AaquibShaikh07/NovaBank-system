from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation

from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from sqlalchemy import func

from app.models import db, Account, Transaction

transactions_bp = Blueprint("transactions", __name__)


def _get_owned_account_or_404(account_id):
    """Customers may only operate on their own accounts."""
    account = Account.query.get_or_404(account_id)
    if current_user.role == "customer" and account.user_id != current_user.id:
        return None
    return account


def _parse_amount(raw):
    try:
        amount = Decimal(raw)
    except (InvalidOperation, TypeError):
        return None
    if amount <= 0:
        return None
    return amount.quantize(Decimal("0.01"))


@transactions_bp.route("/accounts/<int:account_id>/deposit", methods=["GET", "POST"])
@login_required
def deposit(account_id):
    account = _get_owned_account_or_404(account_id)
    if account is None:
        flash("You don't have permission to access that account.", "danger")
        return redirect(url_for("dashboard.home"))

    if request.method == "POST":
        amount = _parse_amount(request.form.get("amount"))
        if amount is None:
            flash("Enter a valid deposit amount.", "danger")
            return redirect(url_for("transactions.deposit", account_id=account.id))

        if account.status != "active":
            flash(f"This account is {account.status} and cannot accept deposits.", "danger")
            return redirect(url_for("dashboard.home"))

        account.balance = Decimal(account.balance) + amount
        txn = Transaction(
            reference=Transaction.generate_reference(),
            account_id=account.id,
            type="deposit",
            amount=amount,
            balance_after=account.balance,
            description=request.form.get("description") or "Cash deposit",
        )
        db.session.add(txn)
        db.session.commit()

        flash(f"Deposited {current_app.config['CURRENCY_SYMBOL']}{amount} successfully.", "success")
        return redirect(url_for("transactions.receipt", txn_id=txn.id))

    return render_template("deposit.html", account=account)


@transactions_bp.route("/accounts/<int:account_id>/withdraw", methods=["GET", "POST"])
@login_required
def withdraw(account_id):
    account = _get_owned_account_or_404(account_id)
    if account is None:
        flash("You don't have permission to access that account.", "danger")
        return redirect(url_for("dashboard.home"))

    if request.method == "POST":
        amount = _parse_amount(request.form.get("amount"))
        if amount is None:
            flash("Enter a valid withdrawal amount.", "danger")
            return redirect(url_for("transactions.withdraw", account_id=account.id))

        if account.status != "active":
            flash(f"This account is {account.status} and cannot be withdrawn from.", "danger")
            return redirect(url_for("dashboard.home"))

        if amount > Decimal(account.balance):
            flash("Insufficient balance for this withdrawal.", "danger")
            return redirect(url_for("transactions.withdraw", account_id=account.id))

        limit = Decimal(str(current_app.config["DAILY_WITHDRAWAL_LIMIT"]))
        today_total = _today_withdrawn(account.id)
        if today_total + amount > limit:
            flash(
                f"Daily withdrawal limit is {current_app.config['CURRENCY_SYMBOL']}{limit}. "
                f"You've already withdrawn {current_app.config['CURRENCY_SYMBOL']}{today_total} today.",
                "danger",
            )
            return redirect(url_for("transactions.withdraw", account_id=account.id))

        account.balance = Decimal(account.balance) - amount
        txn = Transaction(
            reference=Transaction.generate_reference(),
            account_id=account.id,
            type="withdrawal",
            amount=amount,
            balance_after=account.balance,
            description=request.form.get("description") or "Cash withdrawal",
        )
        db.session.add(txn)
        db.session.commit()

        flash(f"Withdrew {current_app.config['CURRENCY_SYMBOL']}{amount} successfully.", "success")
        return redirect(url_for("transactions.receipt", txn_id=txn.id))

    return render_template("withdraw.html", account=account)


@transactions_bp.route("/accounts/<int:account_id>/transfer", methods=["GET", "POST"])
@login_required
def transfer(account_id):
    account = _get_owned_account_or_404(account_id)
    if account is None:
        flash("You don't have permission to access that account.", "danger")
        return redirect(url_for("dashboard.home"))

    if request.method == "POST":
        target_number = request.form.get("target_account", "").strip()
        amount = _parse_amount(request.form.get("amount"))

        if amount is None:
            flash("Enter a valid transfer amount.", "danger")
            return redirect(url_for("transactions.transfer", account_id=account.id))

        target = Account.query.filter_by(account_number=target_number).first()
        if not target:
            flash("Destination account number not found.", "danger")
            return redirect(url_for("transactions.transfer", account_id=account.id))

        if target.id == account.id:
            flash("You cannot transfer to the same account.", "danger")
            return redirect(url_for("transactions.transfer", account_id=account.id))

        if account.status != "active" or target.status != "active":
            flash("One of the accounts involved is not active.", "danger")
            return redirect(url_for("transactions.transfer", account_id=account.id))

        if amount > Decimal(account.balance):
            flash("Insufficient balance for this transfer.", "danger")
            return redirect(url_for("transactions.transfer", account_id=account.id))

        # Debit sender, credit receiver, in one atomic commit.
        account.balance = Decimal(account.balance) - amount
        target.balance = Decimal(target.balance) + amount

        out_txn = Transaction(
            reference=Transaction.generate_reference(),
            account_id=account.id,
            related_account_id=target.id,
            type="transfer_out",
            amount=amount,
            balance_after=account.balance,
            description=request.form.get("description") or f"Transfer to {target.account_number}",
        )
        in_txn = Transaction(
            reference=Transaction.generate_reference(),
            account_id=target.id,
            related_account_id=account.id,
            type="transfer_in",
            amount=amount,
            balance_after=target.balance,
            description=f"Transfer from {account.account_number}",
        )
        db.session.add_all([out_txn, in_txn])
        db.session.commit()

        flash(f"Transferred {current_app.config['CURRENCY_SYMBOL']}{amount} to {target.account_number}.", "success")
        return redirect(url_for("transactions.receipt", txn_id=out_txn.id))

    return render_template("transfer.html", account=account)


@transactions_bp.route("/accounts/<int:account_id>/statement")
@login_required
def statement(account_id):
    account = _get_owned_account_or_404(account_id)
    if account is None:
        flash("You don't have permission to access that account.", "danger")
        return redirect(url_for("dashboard.home"))

    page = request.args.get("page", 1, type=int)
    pagination = (
        Transaction.query.filter_by(account_id=account.id)
        .order_by(Transaction.created_at.desc())
        .paginate(page=page, per_page=15, error_out=False)
    )

    return render_template("statement.html", account=account, pagination=pagination)


@transactions_bp.route("/receipt/<int:txn_id>")
@login_required
def receipt(txn_id):
    txn = Transaction.query.get_or_404(txn_id)
    account = _get_owned_account_or_404(txn.account_id)
    if account is None:
        flash("You don't have permission to view that receipt.", "danger")
        return redirect(url_for("dashboard.home"))

    return render_template("receipt.html", txn=txn, account=account)


def _today_withdrawn(account_id):
    start = datetime.combine(datetime.utcnow().date(), datetime.min.time())
    total = (
        db.session.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.account_id == account_id,
            Transaction.type == "withdrawal",
            Transaction.created_at >= start,
        )
        .scalar()
    )
    return Decimal(total)
