from flask import Blueprint, render_template
from flask_login import login_required, current_user
from sqlalchemy import func

from app.models import db, User, Account, Transaction

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard")
@login_required
def home():
    if current_user.role in ("admin", "employee"):
        total_customers = User.query.filter_by(role="customer").count()
        total_accounts = Account.query.count()
        total_deposits = db.session.query(func.coalesce(func.sum(Account.balance), 0)).scalar()

        recent_txns = (
            Transaction.query.order_by(Transaction.created_at.desc()).limit(10).all()
        )

        # Last 6 months of deposit/withdrawal volume, for the Chart.js widget.
        chart_labels, deposit_series, withdrawal_series = _monthly_volume()

        return render_template(
            "admin_dashboard.html",
            total_customers=total_customers,
            total_accounts=total_accounts,
            total_deposits=total_deposits,
            recent_txns=recent_txns,
            chart_labels=chart_labels,
            deposit_series=deposit_series,
            withdrawal_series=withdrawal_series,
        )

    # Customer view
    accounts = Account.query.filter_by(user_id=current_user.id).all()
    recent_txns = []
    for acc in accounts:
        recent_txns.extend(acc.transactions[:5])
    recent_txns.sort(key=lambda t: t.created_at, reverse=True)
    recent_txns = recent_txns[:10]

    return render_template(
        "customer_dashboard.html", accounts=accounts, recent_txns=recent_txns
    )


def _monthly_volume():
    """Aggregate deposits/withdrawals by month for the last 6 months (SQLite-friendly)."""
    rows = (
        db.session.query(
            func.strftime("%Y-%m", Transaction.created_at).label("month"),
            Transaction.type,
            func.sum(Transaction.amount),
        )
        .group_by("month", Transaction.type)
        .order_by("month")
        .all()
    )

    months = sorted({r[0] for r in rows})[-6:]
    deposits = {m: 0 for m in months}
    withdrawals = {m: 0 for m in months}

    for month, ttype, total in rows:
        if month not in months:
            continue
        if ttype == "deposit":
            deposits[month] = float(total)
        elif ttype == "withdrawal":
            withdrawals[month] = float(total)

    return months, [deposits[m] for m in months], [withdrawals[m] for m in months]
